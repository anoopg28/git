#!/bin/bash
echo "Hello my first docker file" 
